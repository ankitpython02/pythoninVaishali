from django.apps import AppConfig


class CrudoperationConfig(AppConfig):
    name = 'crudoperation'
