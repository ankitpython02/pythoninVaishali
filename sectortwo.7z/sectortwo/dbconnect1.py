import mysql.connector

db = mysql.connector.connect(user="root", passwd="", host="localhost")
print('Connected with vaishali')