from django.shortcuts import render
from django.http import HttpResponse
from .models import Destination

# Create your views here.


def index(request):
    dest1 = Destination()
    dest1.name = 'Varanasi'
    dest1.price = 1200
    dest1.img = '01-greece.jpg'

    dest2 = Destination()
    dest2.name = 'Delhi'
    dest2.price = 800
    dest2.img ='02-rome.jpg'


    dest3 = Destination()
    dest3.name = 'Noida'
    dest3.price = 1111
    dest3.img = '03-japan.jpg'

    dest = [dest1, dest2, dest3]
    return render(request, 'index.html', {'dest': dest})