from django.apps import AppConfig


class TravelerConfig(AppConfig):
    name = 'traveler'
